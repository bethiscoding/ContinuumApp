//
//  ImageSelectorViewController.swift
//  Continuum
//
//  Created by Bethany Morris on 5/13/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

import UIKit

protocol ImageSelectorViewControllerDelegate: class {
    func imageSelectorViewControllerSelected(image: UIImage)
}

class ImageSelectorViewController: UIViewController {

    // MARK: - Outlets & Properties
    
    @IBOutlet weak var postImageView: UIImageView!
    @IBOutlet weak var selectImageButton: UIButton!
    
    weak var delegate: ImageSelectorViewControllerDelegate?
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        postImageView.image = nil
        selectImageButton.setTitle("Select Image", for: .normal)
    }
    
    // MARK: - Actions
    
    @IBAction func selectImageButtonTapped(_ sender: UIButton) {
        presentImagePickerActionSheet()
    }
    
} //End

// MARK: - Extensions

extension ImageSelectorViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        picker.dismiss(animated: true, completion: nil)
        
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            selectImageButton.setTitle("", for: .normal)
            postImageView.image = image
            delegate?.imageSelectorViewControllerSelected(image: image)
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    func presentImagePickerActionSheet() {
        
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        
        let actionSheet = UIAlertController(title: "Select Image", message: nil, preferredStyle: .actionSheet)
        if #available(iOS 13.0, *) {
            actionSheet.setBackgroundColor(color: .secondaryLabel)
        } else {
            actionSheet.setBackgroundColor(color: .darkGray)
        }
        actionSheet.view.tintColor = .white
        
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            actionSheet.addAction(UIAlertAction(title: "Photos", style: .default, handler: { (_) in
                imagePickerController.sourceType = UIImagePickerController.SourceType.photoLibrary
                self.present(imagePickerController, animated: true, completion: nil)
            }))
        }
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (_) in
                imagePickerController.sourceType = UIImagePickerController.SourceType.camera
                self.present(imagePickerController, animated: true, completion: nil)
            }))
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        cancelAction.setValue(UIColor.black, forKey: "titleTextColor")
        
        actionSheet.addAction(cancelAction)
        
        present(actionSheet, animated: true)
    }
    
} //End
