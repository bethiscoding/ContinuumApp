//
//  Post.swift
//  Continuum
//
//  Created by Bethany Morris on 5/12/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

import UIKit
import CloudKit

struct PostStrings {
    static let recordTypeKey = "Post"
    static let timestampKey = "timestamp"
    static let captionKey = "caption"
    static let commentsKey = "comments"
    static let imageAssetKey = "imageAsset"
}

class Post {
    
    var photoData: Data?
    let timestamp: Date
    let caption: String
    var comments: [Comment]
    var recordID: CKRecord.ID
    
    var image: UIImage? {
        get {
            guard let photoData = photoData else { return nil }
            return UIImage(data: photoData)
        } set {
            photoData = newValue?.jpegData(compressionQuality: 0.5)
        }
    }
    
    var imageAsset: CKAsset? {
        get {
            guard photoData != nil else { return nil }
            let tempDirectory = NSTemporaryDirectory()
            let tempDirectoryURL = URL(fileURLWithPath: tempDirectory)
            let fileURL = tempDirectoryURL.appendingPathComponent(UUID().uuidString).appendingPathExtension("jpg")
            
            do {
                try photoData?.write(to: fileURL)
            } catch {
                print(error)
                print(error.localizedDescription)
            }
            
            return CKAsset(fileURL: fileURL)
        }
    }
    
    init(image: UIImage?, timestamp: Date = Date(), caption: String, comments: [Comment] = [], recordID: CKRecord.ID = CKRecord.ID(recordName: UUID().uuidString)) {
        self.timestamp = timestamp
        self.caption = caption
        self.comments = comments
        self.recordID = recordID
        self.image = image
    }
    
} //End

// MARK: - Extensions

extension Post {
    
    convenience init?(ckRecord: CKRecord) {
        guard let timestamp = ckRecord[PostStrings.timestampKey] as? Date,
            let caption = ckRecord[PostStrings.captionKey] as? String
            else { return nil }
        
        var foundImage: UIImage?
        if let imageAsset = ckRecord[PostStrings.imageAssetKey] as? CKAsset {
            do {
                let data = try Data(contentsOf: imageAsset.fileURL)
                foundImage = UIImage(data: data)
            } catch {
                print(error)
                print(error.localizedDescription)
            }
        }
         
        self.init(image: foundImage, timestamp: timestamp, caption: caption, comments: [], recordID: ckRecord.recordID)
    }
    
} //End

extension Post: SearchableRecords {
    
    func matches(searchTerm: String) -> Bool {
        if caption.lowercased().contains(searchTerm.lowercased()) {
            return true
        } else {
            for comment in comments {
                if comment.matches(searchTerm: searchTerm) {
                return true
                }
            }
        }
        return false
    }
    
} //End

extension CKRecord {
    
    convenience init(post: Post) {
        self.init(recordType: PostStrings.recordTypeKey, recordID: post.recordID)
        
        self.setValuesForKeys([
            PostStrings.timestampKey : post.timestamp,
            PostStrings.captionKey : post.caption,
            PostStrings.imageAssetKey : post.imageAsset
        ])
    }
    
} //End
