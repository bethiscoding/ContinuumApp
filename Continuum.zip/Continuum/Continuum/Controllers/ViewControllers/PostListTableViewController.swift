//
//  PostListTableViewController.swift
//  Continuum
//
//  Created by Bethany Morris on 5/12/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

import UIKit

class PostListTableViewController: UITableViewController {

    // MARK: - Outlets & Properties
    
    @IBOutlet weak var postSearchBar: UISearchBar!
    
    var results: [Post] = []
    var isSearching = false
    var dataSource: [Post] {
        return isSearching ? results : PostController.sharedInstance.posts
    }
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        postSearchBar.delegate = self
        performFullSync(completion: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        DispatchQueue.main.async {
            self.results = PostController.sharedInstance.posts
            self.tableView.reloadData()
        }
    }

    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return dataSource.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "PostCell", for: indexPath) as? PostTableViewCell else { return UITableViewCell() }

        let post = dataSource[indexPath.row]
        cell.post = post
        
        return cell
    }
    
    // MARK: - Methods
    
    func performFullSync(completion:((Bool) ->Void)?){
        
//        self.activityView.isHidden = false
//        self.activityIndicator.startAnimating()
        
        PostController.sharedInstance.fetchPosts { (result) in
            switch result {
            case .failure(let error):
                self.presentSimpleAlertWith(title: "An error occurred", message: error.localizedDescription)
                print(error.localizedDescription)
                completion?(false)
            case .success(let posts):
                DispatchQueue.main.async {
//                    self.activityView.isHidden = true
//                    self.activityIndicator.stopAnimating()
                    self.tableView.reloadData()
                    completion?(posts != nil)
                }
            }
        }
    }

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // IIDOO
        if segue.identifier == "ToPostDetailTVC" {
            guard let indexPath = tableView.indexPathForSelectedRow, let destinationVC = segue.destination as? PostDetailTableViewController else { return }
            let post = dataSource[indexPath.row]
            destinationVC.post = post
        }
    }

} //End

// MARK: - Extensions

extension PostListTableViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        results = PostController.sharedInstance.posts.filter { $0.matches(searchTerm: searchText.lowercased())}
        tableView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        results = PostController.sharedInstance.posts
        tableView.reloadData()
        searchBar.text = ""
        searchBar.resignFirstResponder()
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        isSearching = true
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        isSearching = false
    }
    
} //End
