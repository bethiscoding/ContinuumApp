//
//  AddPostTableViewController.swift
//  Continuum
//
//  Created by Bethany Morris on 5/12/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

import UIKit

class AddPostTableViewController: UITableViewController {

    // MARK: - Outlets & Properties
    
    @IBOutlet weak var captionTextField: UITextField!
    
    var selectedImage: UIImage?
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        captionTextField.text = nil
    }

    // MARK: - Actions & Methods
    
    @IBAction func addPostButtonTapped(_ sender: UIButton) {
        if let image = selectedImage, let caption = captionTextField.text {
            PostController.sharedInstance.createPostWith(image: image, caption: caption) { (result) in }
            guard let myTabBarController = self.tabBarController as? TabBarViewController else { return }
            myTabBarController.animateToTab(toIndex: 0)
        } else {
            presentAlertController()
        }
    }
    
    @IBAction func cancelButtonTapped(_ sender: UIBarButtonItem) {
        guard let myTabBarController = self.tabBarController as? TabBarViewController else { return }
        myTabBarController.animateToTab(toIndex: 0)
    }
    
    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ToImageSelectorVC" {
            let imageSelector = segue.destination as? ImageSelectorViewController
            imageSelector?.delegate = self
        }
    }

} //End

// MARK: - Extensions

extension AddPostTableViewController: ImageSelectorViewControllerDelegate {
    func imageSelectorViewControllerSelected(image: UIImage) {
        selectedImage = image
    }
    
} //End

extension AddPostTableViewController {
    
    func presentAlertController() {
        
        let alertController = UIAlertController(title: "Oops!", message: "You cannot save a post without an image or a caption.", preferredStyle: .alert)
        alertController.setBackgroundColor(color: .black)
        alertController.setTitle(font: nil, color: .white)
        alertController.setMessage(font: nil, color: .white)
        alertController.setTint(color: .white)
        
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        
        alertController.addAction(cancelAction)
        
        present(alertController, animated: true)
    }
    
} //End
