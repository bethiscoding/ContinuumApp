//
//  PostController.swift
//  Continuum
//
//  Created by Bethany Morris on 5/12/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

import UIKit
import CloudKit

class PostController {
    
    // MARK: - Singleton
    
    static let sharedInstance = PostController()
    
    // MARK: - Properties
    
    var posts: [Post] = []
    let publicDB = CKContainer.default().publicCloudDatabase
    
    // MARK: - Create Methods
    
    func addComment(text: String, post: Post, completion: @escaping (Result<Comment, PostError>) -> Void ) {
        
        let postReference = CKRecord.Reference(recordID: post.recordID, action: .none)
        
        let newComment = Comment(text: text, postReference: postReference)
        post.comments.append(newComment)
        
        let record = CKRecord(comment: newComment)
        
        publicDB.save(record) { (record, error) in
            if let error = error {
                return completion(.failure(.ckError(error)))
            }
            
            guard let record = record,
                let savedComment = Comment(ckRecord: record)
                else { return completion(.failure(.noRecord))}
            print("Saved comment successfully")
            completion(.success(savedComment))
        }
    }
    
    func createPostWith(image: UIImage, caption: String, completion: @escaping (Result<Post?, PostError>) -> Void ) {
        
        let newPost = Post(image: image, caption: caption)
        posts.append(newPost)
        
        let record = CKRecord(post: newPost)
        
        publicDB.save(record) { (record, error) in
            if let error = error {
                return completion(.failure(.ckError(error)))
            }
            
            guard let record = record,
                let savedPost = Post(ckRecord: record)
                else { return completion(.failure(.noPost))}
            print("Saved post successfully")
            completion(.success(savedPost))
        }
    }
    
    //MARK: - Read Methods
    
    func fetchPosts(completion: @escaping (Result<[Post]?, PostError>) -> Void){
        
        let fetchPostsPredicate = NSPredicate(value: true)
        let query = CKQuery(recordType: PostStrings.recordTypeKey, predicate: fetchPostsPredicate)
        
        publicDB.perform(query, inZoneWith: nil) { (records, error) in
            
            if let error = error {
                return completion(.failure(.ckError(error)))
            }
            
            guard let records = records else { return completion(.failure(.noRecord)) }
            print("Fetched all posts successfully")
            let posts = records.compactMap{ Post(ckRecord: $0) }
            self.posts = posts
            completion(.success(posts))
        }
    }
    
    func fetchComments(for post: Post, completion: @escaping (Result<[Comment]?, PostError>) -> Void){
        
        let postReference = post.recordID
        let predicate = NSPredicate(format: "%K == %@", CommentStrings.postReferenceKey, postReference)
        
        let commentIDs = post.comments.compactMap({$0.recordID})
        let predicate2 = NSPredicate(format: "NOT(recordID IN %@)", commentIDs)
        
        let compoundPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: [predicate, predicate2])
        let query = CKQuery(recordType: "Comment", predicate: compoundPredicate)
        
        publicDB.perform(query, inZoneWith: nil) { (records, error) in
            
            if let error = error {
                return completion(.failure(.ckError(error)))
            }
            
            guard let records = records else { return completion(.failure(.noRecord)) }
            let comments = records.compactMap{ Comment(ckRecord: $0) }
            post.comments.append(contentsOf: comments)
            completion(.success(comments))
        }
    }
    
    //MARK: - Subscription Methods
    
    func subscribeToNewPosts(completion: ((Bool, Error?) -> Void)?){
        
        let predicate = NSPredicate(value: true)
        let subscription = CKQuerySubscription(recordType: "Post", predicate: predicate, subscriptionID: "AllPosts", options: CKQuerySubscription.Options.firesOnRecordCreation)
        
        let notificationInfo = CKSubscription.NotificationInfo()
        notificationInfo.alertBody = "New post added to Continuum!"
        
        notificationInfo.shouldBadge = true
        notificationInfo.shouldSendContentAvailable = true
        subscription.notificationInfo = notificationInfo
        
        publicDB.save(subscription) { (subscription, error) in
            
            if let error = error {
                print("There was an error in \(#function) ; \(error)  ; \(error.localizedDescription)")
                completion?(false, error)
                return
            } else {
                completion?(true, nil)
            }
        }
    }
    
    func addSubscriptionTo(commentsForPost post: Post, completion: ((Bool, Error?) -> ())?){
        
        let postRecordID = post.recordID
        let predicate = NSPredicate(format: "%K = %@", CommentStrings.postReferenceKey, postRecordID)
        
        let subscription = CKQuerySubscription(recordType: "Comment", predicate: predicate, subscriptionID: post.recordID.recordName, options: CKQuerySubscription.Options.firesOnRecordCreation)
        
        let notificationInfo = CKSubscription.NotificationInfo()
        notificationInfo.title = "New Comment"
        notificationInfo.alertBody = "A new comment was added to a post that you follow!"
        notificationInfo.soundName = "default"
        notificationInfo.shouldSendContentAvailable = true
        notificationInfo.shouldBadge = true
        notificationInfo.desiredKeys = [CommentStrings.textKey, CommentStrings.timestampKey]
        subscription.notificationInfo = notificationInfo
        
        publicDB.save(subscription) { (_, error) in
            
            if let error = error {
                print("There was an error in \(#function) \n---\n \(error) \n---\n \(error.localizedDescription)")
                completion?(false, error)
                return
            } else {
                completion?(true, nil)
            }
        }
    }
    
    func removeSubscriptionTo(commentsForPost post: Post, completion: ((Bool) -> ())?) {
        
        let subscriptionID = post.recordID.recordName
        
        publicDB.delete(withSubscriptionID: subscriptionID) { (_, error) in
            
            if let error = error {
                print("There was an error in \(#function) \n---\n \(error) \n---\n \(error.localizedDescription)")
                completion?(false)
                return
            } else {
                print("Subscription deleted")
                completion?(true)
            }
        }
    }
    
    func checkForSubscription(to post: Post, completion: ((Bool) -> ())?) {
        
        let subscriptionID = post.recordID.recordName
        
        publicDB.fetch(withSubscriptionID: subscriptionID) { (subscription, error) in
            
            if let error = error {
                print("There was an error in \(#function) \n---\n \(error) \n---\n \(error.localizedDescription)")
                completion?(false)
                return
            }
            
            if subscription != nil {
                completion?(true)
            } else {
                completion?(false)
            }
        }
    }
    
    func toggleSubscriptionTo(commentsForPost post: Post, completion: ((Bool, Error?) -> ())?){
        
        checkForSubscription(to: post) { (isSubscribed) in
            
            if isSubscribed{
                self.removeSubscriptionTo(commentsForPost: post, completion: { (success) in
                    if success {
                        print("Successfully removed the subscription to the post with caption: \(post.caption)")
                        completion?(true, nil)
                    } else {
                        print("There was an error removing the subscription to the post with caption: \(post.caption)")
                        completion?(false, nil)
                    }
                })
            } else {
                self.addSubscriptionTo(commentsForPost: post, completion: { (success, error) in
                    if let error = error {
                        print("There was an error in \(#function) \n---\n \(error) \n---\n \(error.localizedDescription)")
                        completion?(false, error)
                        return
                    }
                    if success {
                        print("Successfully subscribed to the post with caption: \(post.caption)")
                        completion?(true, nil)
                    } else {
                        print("There was an error subscribing to the post with caption: \(post.caption)")
                        completion?(false, nil)
                    }
                })
            }
        }
    }
    
} //End
