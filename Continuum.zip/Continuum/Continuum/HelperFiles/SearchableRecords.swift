//
//  SearchableRecords.swift
//  Continuum
//
//  Created by Bethany Morris on 5/13/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

import Foundation

protocol SearchableRecords {
    
    func matches(searchTerm: String) -> Bool
}
