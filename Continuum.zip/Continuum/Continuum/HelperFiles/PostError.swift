//
//  PostError.swift
//  Continuum
//
//  Created by Bethany Morris on 5/12/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

import Foundation

enum PostError: LocalizedError {
    
    case ckError(Error)
    case noRecord
    case noPost
    
    var errorDescription: String {
        switch self{
        case .ckError(let error):
            return error.localizedDescription
        case .noRecord:
            return "No record was returned"
        case .noPost:
            return "The post was not found"
        }
    }
}
